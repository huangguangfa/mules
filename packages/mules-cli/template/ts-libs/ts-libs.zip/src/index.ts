export default function () {
  return 'hello world';
}
