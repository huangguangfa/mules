<template>
  <div class="flex" style="margin: 11px 0">
    <gf-button>普通按钮</gf-button>
    <gf-button color="primary">正常按钮</gf-button>
    <gf-button color="success">成功按钮</gf-button>
    <gf-button color="info">信息按钮</gf-button>
    <gf-button color="warning">警告按钮</gf-button>
    <gf-button color="danger">错误按钮</gf-button>
  </div>
</template>

<script lang="ts" setup></script>
