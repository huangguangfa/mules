export { NOOP } from '@vue/shared'
