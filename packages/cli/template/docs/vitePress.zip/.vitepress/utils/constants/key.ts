export const INSTALLED_KEY = Symbol('INSTALLED_KEY')
