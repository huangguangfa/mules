export type Link = {
  text: string
  link: string
  promotion?: string
  activeMatch: string
}
