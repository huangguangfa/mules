<template>
  <svg
    id="图层_1"
    version="1.1"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"
    x="0px"
    y="0px"
    viewBox="0 0 120 120"
    style="enable-background: new 0 0 120 120"
    xml:space="preserve"
  >
    <path
      class="st0"
      d="M13,15h48c3.3,0,6,2.7,6,6v33c0,3.3-2.7,6-6,6H13c-3.3,0-6-2.7-6-6V21C7,17.7,9.7,15,13,15z"
    />
    <path
      class="st0"
      d="M81,15h20c3.3,0,6,2.7,6,6v33c0,3.3-2.7,6-6,6H81c-3.3,0-6-2.7-6-6V21C75,17.7,77.7,15,81,15z"
    />
    <path
      class="st1"
      d="M12.5,15h49c3,0,5.5,2.5,5.5,5.5l0,0c0,3-2.5,5.5-5.5,5.5h-49c-3,0-5.5-2.5-5.5-5.5l0,0C7,17.5,9.5,15,12.5,15z
      "
    />
    <path
      class="st2"
      d="M80.5,15h21c3,0,5.5,2.5,5.5,5.5l0,0c0,3-2.5,5.5-5.5,5.5h-21c-3,0-5.5-2.5-5.5-5.5l0,0
      C75,17.5,77.5,15,80.5,15z"
    />
    <path
      class="st0"
      d="M90,68c3.3,0,6,2.7,6,6v28c0,2.2-1.8,4-4,4H13c-3.3,0-6-2.7-6-6V74c0-3.3,2.7-6,6-6H90z"
    />
    <path
      class="st2"
      d="M18,73.5v27c0,3-2.5,5.5-5.5,5.5l0,0c-3,0-5.5-2.5-5.5-5.5v-27c0-3,2.5-5.5,5.5-5.5l0,0
      C15.5,68,18,70.5,18,73.5z"
    />
    <path class="st3" d="M84.3,78.7L79.5,68h13.1L84.3,78.7z" />
    <path class="st4" d="M102.1,78.7H84.2L92.6,68L102.1,78.7z" />
    <path class="st5" d="M70,78.7L79.5,68l4.8,10.7H70z" />
    <path class="st6" d="M92.6,68l9.5,10.7l4.8-10.7H92.6z" />
    <path class="st5" d="M106.8,68l8.3,10.7h-13.1L106.8,68z" />
    <path class="st7" d="M93.8,106l21.4-27.3h-13.1L93.8,106z" />
    <path class="st3" d="M70,78.7L93.8,106l-9.5-27.3H70z" />
    <path class="st5" d="M93.8,106l8.3-27.3H84.2L93.8,106z" />
  </svg>
</template>

<style scoped lang="scss">
.st0 {
  fill: #f2f8fe;
}
.st1 {
  fill: #ffd6d2;
}
.st2 {
  fill: #20a0ff;
}
.st3 {
  fill: #6496dc;
}
.st4 {
  fill: #afc8ea;
}
.st5 {
  fill: #80a8e1;
}
.st6 {
  fill: #93b8ee;
}
.st7 {
  fill: #afc8eb;
}

.dark {
  .st0 {
    fill: #3e444a;
  }
}
</style>
