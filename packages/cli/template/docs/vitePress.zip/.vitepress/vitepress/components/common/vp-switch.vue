<script setup lang="ts"></script>

<template>
  <div class="switch" role="switch">
    <div class="switch__action">
      <div class="switch__icon">
        <slot />
      </div>
    </div>
  </div>
</template>
