/// <reference types="vite/client" />

export {}
