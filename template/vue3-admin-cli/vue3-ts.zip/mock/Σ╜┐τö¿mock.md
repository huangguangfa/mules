1、在当前目录创建与接口method同名的js文件即可;
2、 修改js文件不需重启服务, 即时生效;
3、 支持mockjs语法 参考 http://mockjs.com/examples.html