export * from './typescripts'

export type FileType = 'document' | 'documentPro' | 'spreadsheet' | 'presentation'
