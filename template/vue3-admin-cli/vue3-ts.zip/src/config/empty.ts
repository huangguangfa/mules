/*
 * @constant 空类型默认
 */
// eslint-disable-next-line @typescript-eslint/no-empty-function
export const EMPTY_FUNC = function () {}
export const EMPTY_ARRAY = []
export const EMPTY_OBJECT = {}
