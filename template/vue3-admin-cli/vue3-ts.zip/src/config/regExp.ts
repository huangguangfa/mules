/**
 * @constant 正则表达式常量
 */
export const DATA_REGEX_PATTERN = {
  highlight: /[.[*?+^$|()/]|\\]|\\/g,
}
