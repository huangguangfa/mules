export default [
  {
    path: '/error',
    component: () => import('@/components/global/error/index.vue'),
    meta: { title: 'error页面' },
  },
]
