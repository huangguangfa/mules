export default [
  {
    path: '/demo',
    name: 'demo',
    component: () => import('@/components/demo/index.vue'),
  },
]
