export function useTitle(title: string) {
  document.title = title
}
