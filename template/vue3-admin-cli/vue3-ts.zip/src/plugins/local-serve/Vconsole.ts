import Vconsole from 'vconsole'

export function startVconsole() {
  new Vconsole()
}
